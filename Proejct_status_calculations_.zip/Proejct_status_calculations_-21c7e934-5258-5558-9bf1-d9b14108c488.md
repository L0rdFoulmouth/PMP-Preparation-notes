
*   CPI and SPI:
	*   CPI < 1.0 indicates that the project is running over budget.
	*   CPI > 1.0 indicates that the project is running under budget.
	*   CPI = 1 indicates the project is within the budget.
	*   SPI > 1.0 indicates the project is ahead of schedule (earned value is greater than planned value).
	*   SPI < 1.0 indicates the project is behind schedule (earned value is less than planned value).
	*   SPI = 1.0 indicates the project is on schedule (earned value is equal to planned value).
*   Negative schedule variance means the project is behind schedule

