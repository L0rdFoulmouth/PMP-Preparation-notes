
1. Scoring
* create a scoring method by using weighted categories and criterias

2. MoSCoW 
* Must have, Should have, Could have, Wish to have or Won't have

3. Dot voting or multivoting
* Each stakeholder is given a limited number of dots and they should give one, a few or all dots to a particular option
* Option that receives the most dots wins

4. Requirements prioritisation model
* mathematically driven model to calculate priority of features
* Benefit, cost, penalties and risks are rated on a scale of 1 to 9
* Score is calculated through weighted average system to get relative priorities

5. Return on investment
* Project yielding highest ROI is prioritised higher

6. MVP
* Features are decomposed in to smaller marketable packages that deliver value
* Feature that deliver highest value is prioritised first

