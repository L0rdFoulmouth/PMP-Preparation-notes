
* **Coercers**
	* Tell team members what to do and how to do
	* Rarely listen and often seek little input from the team
	* Micro-manager
	* Never provide any type of reward and tend to give more negative feedback than positive feedback
	* Have high standards
	* Inflexible work environment

* **Authoritarian**
	* Firm, but fair
	* Tactful in providing clear directions but leave no doubt about what is expected
	* Frequently solicit input from the team
	* Explain the WHYs but always make final decision
	* High standards as well as high clariity

* **Affiliator**
	* People first
	* Team member's comfort and happiness and their own personal popularity is the highest priority
	* Do not provide clear directions
	* Try to avoid conflicts
	* No accountability

* **Democrat**
	* Group participation and team based decision making
	* Rewards average performance and rarely give negative feedbacks
	* Do not hold team accountable for bad behaviour

* **Pacesetter**
	* Would rather do the job themselves
	* Loners 
	* Expect team to be self-directed
	* Do not spend time mentoring
	* rarely provide positive feedback

* **Coach**
	* Primarily concerned with development of the project team
	* Generally set high standard and work with the team to set those standards
