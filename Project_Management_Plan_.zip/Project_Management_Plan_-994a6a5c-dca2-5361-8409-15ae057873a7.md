|S. No.|Proejct plan|Process where made|Components|Uses|
|---|---|---|---|---|
|1|Scope Management Plan|Plan Scope Management|||
|2|Requirement Management Plan|Plan Scope Management|||
|3|Schedule Management Plan|Plan Schedule Management|||
|4|Cost Management Plan|Plan Cost Management |||
|5|Quality Management Plan|Plan Quality Management|||
|6|Resource Management Plan|Plan Resource Management|||
|7|Comms Management Plan|Plan Comms Management |||
|8|Risk Management Plan|Plan Risk Management|||
|9|Procurement Management Plan|Plan Procurement Management|||
|10|Stakeholder Management Plan|Plan Stakeholder Management |||
|11|Change Management Plan|Develop Project Management Plan|||
|12|Configuration Management Plan|Develop Project Management Plan|||
|13|Scope baseline|Create WBS|||
|14|Schedule Baseline|Develop schedule|||
|15|Cost Baseline|Determine Budget|||
|16|Performance Measurement baseline|Develop Project Management Plan|||
|17|Project life cycle description|Develop Project Management Plan|||
|18|Development approach|Develop Project Management Plan|||
* **Baseline** - what to do
* **Management** **Plan** - How to do

